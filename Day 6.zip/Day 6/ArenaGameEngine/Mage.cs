﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGameEngine
{
    public class Mage : Hero
    {
        public Mage(string name) : base(name)
        {
        }

        public override int Attack()
        {
            int baseAttack = base.Attack();
            int dice = new Random().Next(0, 100);
            if (dice <= 25)
            {
                baseAttack *= 3;
            }
            return baseAttack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            int coef = new Random().Next(10, 51);
            incomingDamage -= (coef * incomingDamage) / 100;
            base.TakeDamage(incomingDamage);
        }
    }
}