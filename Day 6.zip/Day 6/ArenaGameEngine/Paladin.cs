﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGameEngine
{
    public class Paladin : Hero
    {
        public Paladin(string name) : base(name)
        {
        }

        public override int Attack()
        {
            int baseAttack = base.Attack();
            if (new Random().Next(0, 100) <= 20)
            {
                baseAttack *= 2;
            }
            return baseAttack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            int healing = new Random().Next(10, 31);
            Health += healing;
            base.TakeDamage(incomingDamage);
        }
    }
}