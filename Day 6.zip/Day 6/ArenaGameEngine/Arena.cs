﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGameEngine
{
    public class Arena
    {
        public Hero HeroA { get; private set; }

        public Hero HeroB { get; private set; } 

        public Hero HeroC { get; private set; }

        public Hero HeroD { get; private set; }

        public GameEventListener EventListener { get; set; }

        public Arena(Hero a, Hero b, Hero c, Hero d)
        {
            HeroA = a;
            HeroB = b;
            HeroC = c;
            HeroD = d;
        }

        public Hero Battle()
        {
            Hero[] heroes = new Hero[] { HeroA, HeroB, HeroC, HeroD };

            while (true)
            {
                for (int i = 0; i < heroes.Length; i++)
                {
                    Hero attacker = heroes[i];
                    Hero defender = heroes[(i + 2) % 4];

                    int damage = attacker.Attack();
                    defender.TakeDamage(damage);

                    if (EventListener != null)
                    {
                        EventListener.GameRound(attacker, defender, damage);
                    }

                    if (defender.IsDead) return attacker;
                }
            }
        }
    }
}
